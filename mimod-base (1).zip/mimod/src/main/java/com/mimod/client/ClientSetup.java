package com.mimod.client;

import com.mimod.MiMod;
import com.mimod.init.ModBlocks;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderTypeLookup;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = MiMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void alIniciarCliente(FMLClientSetupEvent evento) {
        evento.enqueueWork(() -> {
            RenderTypeLookup.setRenderLayer(ModBlocks.HOJAS_ENCANTADAS.get(), RenderType.cutoutMipped());
            RenderTypeLookup.setRenderLayer(ModBlocks.FAROL_ENCANTADO.get(), RenderType.cutout());
            RenderTypeLookup.setRenderLayer(ModBlocks.PUERTA_ENCANTADA.get(), RenderType.cutout());
            RenderTypeLookup.setRenderLayer(ModBlocks.PORTAL_BOSQUE.get(), RenderType.translucent());
        });
    }
}
