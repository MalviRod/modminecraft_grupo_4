package com.mimod.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

/** Escoba: mantén el clic derecho y vuelas hacia donde miras. */
public class EscobaMagicaItem extends Item {

    public EscobaMagicaItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public ActionResult<ItemStack> use(World mundo, PlayerEntity jugador, Hand mano) {
        jugador.startUsingItem(mano);
        return ActionResult.consume(jugador.getItemInHand(mano));
    }

    @Override
    public UseAction getUseAnimation(ItemStack objeto) {
        return UseAction.NONE;
    }

    @Override
    public int getUseDuration(ItemStack objeto) {
        return 72000;
    }

    @Override
    public void onUseTick(World mundo, LivingEntity ser, ItemStack objeto, int restante) {
        if (!(ser instanceof PlayerEntity)) {
            return;
        }
        Vector3d mira = ser.getLookAngle();
        // 0.08 compensa la gravedad para que la escoba "flote"
        ser.setDeltaMovement(mira.x * 0.6D, mira.y * 0.6D + 0.08D, mira.z * 0.6D);
        ser.fallDistance = 0.0F;

        int usado = getUseDuration(objeto) - restante;
        if (!mundo.isClientSide && usado > 0 && usado % 40 == 0) {
            objeto.hurtAndBreak(1, ser, e -> e.broadcastBreakEvent(e.getUsedItemHand()));
        }
    }

    @Override
    public void releaseUsing(ItemStack objeto, World mundo, LivingEntity ser, int restante) {
        if (!mundo.isClientSide) {
            ser.addEffect(new EffectInstance(Effects.SLOW_FALLING, 100, 0));
        }
    }
}
