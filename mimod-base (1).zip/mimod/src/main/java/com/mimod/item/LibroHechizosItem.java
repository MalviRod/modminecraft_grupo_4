package com.mimod.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

/** Libro: clic derecho elige el siguiente hechizo; agachado + clic derecho muestra la lista. */
public class LibroHechizosItem extends Item {

    public LibroHechizosItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public ActionResult<ItemStack> use(World mundo, PlayerEntity jugador, Hand mano) {
        ItemStack libro = jugador.getItemInHand(mano);
        if (!mundo.isClientSide) {
            if (jugador.isShiftKeyDown()) {
                Hechizo actual = Hechizo.actual(jugador);
                jugador.sendMessage(new StringTextComponent("--- Libro de hechizos ---"), Util.NIL_UUID);
                for (Hechizo h : Hechizo.values()) {
                    String marca = (h == actual) ? "> " : "  ";
                    jugador.sendMessage(
                            new StringTextComponent(marca + h.getNombre() + ": " + h.getDescripcion()), Util.NIL_UUID);
                }
            } else {
                Hechizo h = Hechizo.siguiente(jugador);
                jugador.displayClientMessage(new StringTextComponent("Hechizo seleccionado: " + h.getNombre()), true);
            }
        }
        return ActionResult.sidedSuccess(libro, mundo.isClientSide);
    }
}
