package com.mimod.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

/** Varita: clic derecho lanza el hechizo elegido en el libro de hechizos. */
public class VaritaMagicaItem extends Item {

    public VaritaMagicaItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public ActionResult<ItemStack> use(World mundo, PlayerEntity jugador, Hand mano) {
        ItemStack varita = jugador.getItemInHand(mano);
        if (mundo.isClientSide) {
            return ActionResult.success(varita);
        }

        Hechizo hechizo = Hechizo.actual(jugador);
        switch (hechizo) {
            case LUMOS:
                jugador.addEffect(new EffectInstance(Effects.NIGHT_VISION, 20 * 60, 0));
                break;
            case INCENDIO: {
                Vector3d mira = jugador.getLookAngle();
                SmallFireballEntity bola = new SmallFireballEntity(mundo, jugador, mira.x, mira.y, mira.z);
                bola.setPos(jugador.getX() + mira.x * 1.5D,
                        jugador.getEyeY() - 0.2D + mira.y * 1.5D,
                        jugador.getZ() + mira.z * 1.5D);
                mundo.addFreshEntity(bola);
                break;
            }
            case EXPULSO: {
                AxisAlignedBB zona = jugador.getBoundingBox().inflate(6.0D);
                for (LivingEntity ser : mundo.getEntitiesOfClass(LivingEntity.class, zona, e -> e != jugador)) {
                    Vector3d dir = ser.position().subtract(jugador.position()).normalize();
                    ser.push(dir.x * 1.5D, 0.6D, dir.z * 1.5D);
                    ser.hurtMarked = true;
                }
                break;
            }
        }

        mundo.playSound(null, jugador.getX(), jugador.getY(), jugador.getZ(),
                SoundEvents.EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0F, 1.0F);
        jugador.displayClientMessage(new StringTextComponent("¡" + hechizo.getNombre() + "!"), true);
        jugador.getCooldowns().addCooldown(this, 20);
        varita.hurtAndBreak(1, jugador, p -> p.broadcastBreakEvent(mano));
        return ActionResult.success(varita);
    }
}
