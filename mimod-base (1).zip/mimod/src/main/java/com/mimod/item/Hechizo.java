package com.mimod.item;

import net.minecraft.entity.player.PlayerEntity;

/** Hechizos disponibles. El libro de hechizos elige uno y la varita lo lanza. */
public enum Hechizo {
    LUMOS("Lumos", "Visión nocturna durante un minuto"),
    INCENDIO("Incendio", "Lanza una bola de fuego"),
    EXPULSO("Expulso", "Empuja a los seres cercanos");

    private static final String CLAVE = "mimod_hechizo";

    private final String nombre;
    private final String descripcion;

    Hechizo(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public static Hechizo actual(PlayerEntity jugador) {
        int i = jugador.getPersistentData().getInt(CLAVE);
        return values()[Math.floorMod(i, values().length)];
    }

    public static Hechizo siguiente(PlayerEntity jugador) {
        int i = (jugador.getPersistentData().getInt(CLAVE) + 1) % values().length;
        jugador.getPersistentData().putInt(CLAVE, i);
        return actual(jugador);
    }
}
