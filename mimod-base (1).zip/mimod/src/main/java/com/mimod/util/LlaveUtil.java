package com.mimod.util;

import com.mimod.init.ModItems;
import net.minecraft.entity.player.PlayerEntity;

public class LlaveUtil {
    /** true si el jugador lleva la llave encantada en alguna de las dos manos. */
    public static boolean tieneLlave(PlayerEntity jugador) {
        return jugador.getMainHandItem().getItem() == ModItems.LLAVE_ENCANTADA.get()
                || jugador.getOffhandItem().getItem() == ModItems.LLAVE_ENCANTADA.get();
    }
}
