package com.mimod.init;

import com.mimod.MiMod;
import com.mimod.block.CofreEncantadoBlock;
import com.mimod.block.FarolEncantadoBlock;
import com.mimod.block.PortalBosqueBlock;
import com.mimod.block.PuertaEncantadaBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.RotatedPillarBlock;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraftforge.common.ToolType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MiMod.MOD_ID);

    public static final RegistryObject<Block> TIERRA_ENCANTADA = BLOCKS.register("tierra_encantada",
            () -> new Block(AbstractBlock.Properties.of(Material.DIRT, MaterialColor.COLOR_BLUE)
                    .strength(0.6F).sound(SoundType.GRAVEL).harvestTool(ToolType.SHOVEL)));

    public static final RegistryObject<Block> MADERA_ENCANTADA = BLOCKS.register("madera_encantada",
            () -> new RotatedPillarBlock(AbstractBlock.Properties.of(Material.WOOD, MaterialColor.COLOR_PURPLE)
                    .strength(2.0F).sound(SoundType.WOOD).harvestTool(ToolType.AXE)));

    public static final RegistryObject<Block> HOJAS_ENCANTADAS = BLOCKS.register("hojas_encantadas",
            () -> new LeavesBlock(AbstractBlock.Properties.of(Material.LEAVES, MaterialColor.COLOR_CYAN)
                    .strength(0.2F).randomTicks().sound(SoundType.GRASS).noOcclusion()
                    .isValidSpawn((state, reader, pos, type) -> false)
                    .isSuffocating((state, reader, pos) -> false)
                    .isViewBlocking((state, reader, pos) -> false)));

    public static final RegistryObject<Block> MINERAL_MAGICO = BLOCKS.register("mineral_magico",
            () -> new Block(AbstractBlock.Properties.of(Material.STONE)
                    .strength(3.0F, 3.0F).harvestTool(ToolType.PICKAXE).harvestLevel(1)
                    .requiresCorrectToolForDrops().lightLevel(state -> 5)));

    public static final RegistryObject<Block> FAROL_ENCANTADO = BLOCKS.register("farol_encantado",
            () -> new FarolEncantadoBlock(AbstractBlock.Properties.of(Material.METAL, MaterialColor.COLOR_PURPLE)
                    .strength(1.0F).sound(SoundType.LANTERN).lightLevel(state -> 15).noOcclusion()));

    public static final RegistryObject<Block> COFRE_ENCANTADO = BLOCKS.register("cofre_encantado",
            () -> new CofreEncantadoBlock(AbstractBlock.Properties.of(Material.WOOD, MaterialColor.COLOR_PURPLE)
                    .strength(2.5F).sound(SoundType.WOOD).harvestTool(ToolType.AXE)));

    public static final RegistryObject<Block> PUERTA_ENCANTADA = BLOCKS.register("puerta_encantada",
            () -> new PuertaEncantadaBlock(AbstractBlock.Properties.of(Material.WOOD, MaterialColor.COLOR_PURPLE)
                    .strength(3.0F).sound(SoundType.WOOD).noOcclusion()));

    public static final RegistryObject<Block> PORTAL_BOSQUE = BLOCKS.register("portal_bosque",
            () -> new PortalBosqueBlock(AbstractBlock.Properties.of(Material.PORTAL, MaterialColor.COLOR_PURPLE)
                    .noCollission().strength(-1.0F, 3600000.0F).noDrops().noOcclusion()
                    .lightLevel(state -> 11)
                    .isSuffocating((state, reader, pos) -> false)
                    .isViewBlocking((state, reader, pos) -> false)));
}
