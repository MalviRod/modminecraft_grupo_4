package com.mimod.init;

import com.mimod.MiMod;
import com.mimod.tileentity.CofreEncantadoTileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModTileEntities {
    public static final DeferredRegister<TileEntityType<?>> TILE_ENTITIES =
            DeferredRegister.create(ForgeRegistries.TILE_ENTITIES, MiMod.MOD_ID);

    public static final RegistryObject<TileEntityType<CofreEncantadoTileEntity>> COFRE_ENCANTADO =
            TILE_ENTITIES.register("cofre_encantado",
                    () -> TileEntityType.Builder.of(CofreEncantadoTileEntity::new,
                            ModBlocks.COFRE_ENCANTADO.get()).build(null));
}
