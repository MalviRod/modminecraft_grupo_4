package com.mimod.init;

import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class ModItemGroup {
    public static final ItemGroup TAB = new ItemGroup("bosque_encantado") {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ModItems.GEMA_MAGICA.get());
        }
    };
}
