package com.mimod.init;

import com.mimod.MiMod;
import com.mimod.item.EscobaMagicaItem;
import com.mimod.item.LibroHechizosItem;
import com.mimod.item.VaritaMagicaItem;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.TallBlockItem;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MiMod.MOD_ID);

    private static RegistryObject<Item> bloque(String nombre, RegistryObject<Block> bloque) {
        return ITEMS.register(nombre,
                () -> new BlockItem(bloque.get(), new Item.Properties().tab(ModItemGroup.TAB)));
    }

    // ---- Items de bloques (para tenerlos en el inventario creativo) ----
    public static final RegistryObject<Item> TIERRA_ENCANTADA = bloque("tierra_encantada", ModBlocks.TIERRA_ENCANTADA);
    public static final RegistryObject<Item> MADERA_ENCANTADA = bloque("madera_encantada", ModBlocks.MADERA_ENCANTADA);
    public static final RegistryObject<Item> HOJAS_ENCANTADAS = bloque("hojas_encantadas", ModBlocks.HOJAS_ENCANTADAS);
    public static final RegistryObject<Item> MINERAL_MAGICO = bloque("mineral_magico", ModBlocks.MINERAL_MAGICO);
    public static final RegistryObject<Item> FAROL_ENCANTADO = bloque("farol_encantado", ModBlocks.FAROL_ENCANTADO);
    public static final RegistryObject<Item> COFRE_ENCANTADO = bloque("cofre_encantado", ModBlocks.COFRE_ENCANTADO);
    public static final RegistryObject<Item> PORTAL_BOSQUE = bloque("portal_bosque", ModBlocks.PORTAL_BOSQUE);

    public static final RegistryObject<Item> PUERTA_ENCANTADA = ITEMS.register("puerta_encantada",
            () -> new TallBlockItem(ModBlocks.PUERTA_ENCANTADA.get(), new Item.Properties().tab(ModItemGroup.TAB)));

    // ---- Objetos ----
    public static final RegistryObject<Item> GEMA_MAGICA = ITEMS.register("gema_magica",
            () -> new Item(new Item.Properties().tab(ModItemGroup.TAB)));

    public static final RegistryObject<Item> VARITA_MAGICA = ITEMS.register("varita_magica",
            () -> new VaritaMagicaItem(new Item.Properties().tab(ModItemGroup.TAB).durability(250)));

    public static final RegistryObject<Item> ESCOBA_MAGICA = ITEMS.register("escoba_magica",
            () -> new EscobaMagicaItem(new Item.Properties().tab(ModItemGroup.TAB).durability(500)));

    public static final RegistryObject<Item> LLAVE_ENCANTADA = ITEMS.register("llave_encantada",
            () -> new Item(new Item.Properties().tab(ModItemGroup.TAB).stacksTo(1)));

    public static final RegistryObject<Item> LIBRO_HECHIZOS = ITEMS.register("libro_hechizos",
            () -> new LibroHechizosItem(new Item.Properties().tab(ModItemGroup.TAB).stacksTo(1)));
}
