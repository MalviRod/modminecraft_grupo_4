package com.mimod;

import com.mimod.init.ModBlocks;
import com.mimod.init.ModItems;
import com.mimod.init.ModTileEntities;
import com.mimod.world.ModFeatures;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(MiMod.MOD_ID)
public class MiMod {
    public static final String MOD_ID = "mimod";
    public static final Logger LOGGER = LogManager.getLogger();

    public MiMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTileEntities.TILE_ENTITIES.register(bus);
        ModFeatures.FEATURES.register(bus);

        bus.addListener(this::setup);
    }

    private void setup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModFeatures::registrarConfigurados);
        LOGGER.info("Bosque Encantado cargado correctamente en 1.16.5");
    }
}
