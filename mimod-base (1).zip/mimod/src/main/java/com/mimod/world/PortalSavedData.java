package com.mimod.world;

import com.mimod.MiMod;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.storage.WorldSavedData;

/** Guarda en el mundo dónde están los dos portales para no construirlos dos veces. */
public class PortalSavedData extends WorldSavedData {
    private static final String NOMBRE = MiMod.MOD_ID + "_portales";

    private BlockPos origenOverworld;
    private BlockPos origenBosque;

    public PortalSavedData() {
        super(NOMBRE);
    }

    public static PortalSavedData get(ServerWorld overworld) {
        return overworld.getDataStorage().computeIfAbsent(PortalSavedData::new, NOMBRE);
    }

    @Override
    public void load(CompoundNBT nbt) {
        origenOverworld = nbt.contains("overworld") ? BlockPos.of(nbt.getLong("overworld")) : null;
        origenBosque = nbt.contains("bosque") ? BlockPos.of(nbt.getLong("bosque")) : null;
    }

    @Override
    public CompoundNBT save(CompoundNBT nbt) {
        if (origenOverworld != null) {
            nbt.putLong("overworld", origenOverworld.asLong());
        }
        if (origenBosque != null) {
            nbt.putLong("bosque", origenBosque.asLong());
        }
        return nbt;
    }

    public BlockPos getOrigenOverworld() {
        return origenOverworld;
    }

    public void setOrigenOverworld(BlockPos pos) {
        this.origenOverworld = pos;
        setDirty();
    }

    public BlockPos getOrigenBosque() {
        return origenBosque;
    }

    public void setOrigenBosque(BlockPos pos) {
        this.origenBosque = pos;
        setDirty();
    }
}
