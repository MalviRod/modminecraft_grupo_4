package com.mimod.world;

import com.mimod.init.ModBlocks;
import com.mojang.serialization.Codec;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ISeedReader;
import net.minecraft.world.gen.ChunkGenerator;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.NoFeatureConfig;

import java.util.Random;

/** Árbol del Bosque Encantado: tronco de madera violeta y copa de hojas turquesa. */
public class ArbolEncantadoFeature extends Feature<NoFeatureConfig> {

    public ArbolEncantadoFeature(Codec<NoFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public boolean place(ISeedReader mundo, ChunkGenerator generador, Random azar, BlockPos pos, NoFeatureConfig config) {
        // Solo crece sobre la tierra encantada
        if (!mundo.getBlockState(pos.below()).is(ModBlocks.TIERRA_ENCANTADA.get())) {
            return false;
        }

        int altura = 5 + azar.nextInt(3);

        // Comprobar que hay espacio para el tronco
        for (int y = 0; y <= altura + 1; y++) {
            BlockState s = mundo.getBlockState(pos.above(y));
            if (!(s.isAir() || s.is(BlockTags.LEAVES))) {
                return false;
            }
        }

        BlockState madera = ModBlocks.MADERA_ENCANTADA.get().defaultBlockState();
        BlockState hojas = ModBlocks.HOJAS_ENCANTADAS.get().defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);

        // Tronco
        for (int y = 0; y < altura; y++) {
            mundo.setBlock(pos.above(y), madera, 2);
        }

        // Copa
        for (int dy = altura - 3; dy <= altura + 1; dy++) {
            int radio = (dy >= altura) ? 1 : 2;
            if (dy == altura + 1) {
                radio = 1;
            }
            for (int dx = -radio; dx <= radio; dx++) {
                for (int dz = -radio; dz <= radio; dz++) {
                    boolean esquina = Math.abs(dx) == radio && Math.abs(dz) == radio;
                    if (esquina && (radio == 1 || azar.nextBoolean())) {
                        continue;
                    }
                    BlockPos p = pos.offset(dx, dy, dz);
                    if (mundo.getBlockState(p).isAir()) {
                        mundo.setBlock(p, hojas, 2);
                    }
                }
            }
        }
        return true;
    }
}
