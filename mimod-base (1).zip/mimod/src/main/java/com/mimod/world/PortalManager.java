package com.mimod.world;

import com.mimod.MiMod;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** Lógica del viaje entre el mundo normal y el Bosque Encantado. */
public class PortalManager {
    public static final RegistryKey<World> BOSQUE =
            RegistryKey.create(Registry.DIMENSION_REGISTRY, new ResourceLocation(MiMod.MOD_ID, "bosque_encantado"));

    private static final String CLAVE_ESPERA = "mimod_portal_espera";

    public static void usarPortal(ServerPlayerEntity jugador) {
        MinecraftServer servidor = jugador.getServer();
        if (servidor == null) {
            return;
        }

        // Pequeña espera para no rebotar de un lado a otro
        long ahora = jugador.level.getGameTime();
        long ultimo = jugador.getPersistentData().getLong(CLAVE_ESPERA);
        if (ahora >= ultimo && ahora - ultimo < 80) {
            return;
        }
        jugador.getPersistentData().putLong(CLAVE_ESPERA, ahora);

        ServerWorld overworld = servidor.overworld();
        ServerWorld bosque = servidor.getLevel(BOSQUE);
        if (bosque == null) {
            jugador.displayClientMessage(new StringTextComponent(
                    "El Bosque Encantado no existe en este mundo. Crea un mundo nuevo."), true);
            return;
        }

        PortalSavedData datos = PortalSavedData.get(overworld);
        ServerWorld destino;
        BlockPos origen;

        if (jugador.level.dimension().equals(BOSQUE)) {
            // Volver al mundo normal
            destino = overworld;
            origen = datos.getOrigenOverworld();
            if (origen == null) {
                BlockPos spawn = overworld.getSharedSpawnPos();
                origen = PortalStructure.construir(overworld, spawn.getX() - 1, spawn.getZ() + 9);
                datos.setOrigenOverworld(origen);
            }
        } else {
            // Ir al Bosque Encantado
            destino = bosque;
            origen = datos.getOrigenBosque();
            if (origen == null) {
                origen = PortalStructure.construir(bosque, 0, 0);
                datos.setOrigenBosque(origen);
            }
        }

        double[] p = PortalStructure.llegada(origen);
        jugador.fallDistance = 0.0F;
        jugador.teleportTo(destino, p[0], p[1], p[2], 180.0F, 0.0F);
    }
}
