package com.mimod.world;

import com.mimod.MiMod;
import com.mimod.init.ModBlocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.WorldGenRegistries;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.Features;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.gen.feature.NoFeatureConfig;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.placement.AtSurfaceWithExtraConfig;
import net.minecraft.world.gen.placement.Placement;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, MiMod.MOD_ID);

    public static final RegistryObject<Feature<NoFeatureConfig>> ARBOL_ENCANTADO =
            FEATURES.register("arbol_encantado", () -> new ArbolEncantadoFeature(NoFeatureConfig.CODEC));

    public static ConfiguredFeature<?, ?> ARBOL_CONFIGURADO;
    public static ConfiguredFeature<?, ?> MINERAL_CONFIGURADO;

    /** Se llama una vez al iniciar (FMLCommonSetupEvent). */
    public static void registrarConfigurados() {
        ARBOL_CONFIGURADO = Registry.register(WorldGenRegistries.CONFIGURED_FEATURE,
                new ResourceLocation(MiMod.MOD_ID, "arbol_encantado"),
                ARBOL_ENCANTADO.get().configured(IFeatureConfig.NONE)
                        .decorated(Features.Placements.HEIGHTMAP_SQUARE)
                        .decorated(Placement.COUNT_EXTRA.configured(new AtSurfaceWithExtraConfig(7, 0.2F, 2))));

        MINERAL_CONFIGURADO = Registry.register(WorldGenRegistries.CONFIGURED_FEATURE,
                new ResourceLocation(MiMod.MOD_ID, "mineral_magico"),
                Feature.ORE.configured(new OreFeatureConfig(OreFeatureConfig.FillerBlockType.NATURAL_STONE,
                                ModBlocks.MINERAL_MAGICO.get().defaultBlockState(), 7))
                        .range(64).squared().count(14));
    }
}
