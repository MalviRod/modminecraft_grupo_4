package com.mimod.world;

import com.mimod.init.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.material.Material;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.SignTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.server.ServerWorld;

import java.util.Random;

/**
 * Construye el andén con el portal (estilo andén 9 3/4).
 * El frente mira al norte (-Z): el jugador que aparece mirando al sur camina hacia él.
 *
 * Coordenadas locales: dx = este/oeste, dz = norte/sur (0 = pared), dy = altura sobre el suelo.
 */
public class PortalStructure {

    public static BlockPos construir(ServerWorld mundo, int cx, int cz) {
        // Cargar (y generar) todos los chunks que toca la estructura
        for (int x = (cx - 5) >> 4; x <= (cx + 6) >> 4; x++) {
            for (int z = (cz - 6) >> 4; z <= (cz + 1) >> 4; z++) {
                mundo.getChunk(x, z);
            }
        }

        int base = alturaSuelo(mundo, cx + 1, cz - 3);
        Random azar = mundo.random;

        BlockState aire = Blocks.AIR.defaultBlockState();
        BlockState ladrillo = Blocks.BRICKS.defaultBlockState();
        BlockState piedra = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState musgo = Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        BlockState agrietado = Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
        BlockState cincelado = Blocks.CHISELED_STONE_BRICKS.defaultBlockState();
        BlockState portal = ModBlocks.PORTAL_BOSQUE.get().defaultBlockState();

        // 1) Despejar la zona (quita árboles y desniveles)
        for (int dx = -5; dx <= 6; dx++) {
            for (int dz = -6; dz <= 1; dz++) {
                for (int dy = 0; dy <= 9; dy++) {
                    poner(mundo, cx + dx, base + dy, cz + dz, aire);
                }
            }
        }

        // 2) Suelo del andén (y relleno por debajo para que no queden huecos)
        for (int dx = -5; dx <= 6; dx++) {
            for (int dz = -6; dz <= 1; dz++) {
                int r = azar.nextInt(10);
                poner(mundo, cx + dx, base - 1, cz + dz, r < 6 ? piedra : (r < 8 ? musgo : agrietado));
                for (int dy = -4; dy <= -2; dy++) {
                    BlockPos p = new BlockPos(cx + dx, base + dy, cz + dz);
                    if (esAireOReemplazable(mundo.getBlockState(p))) {
                        mundo.setBlock(p, piedra, 2);
                    }
                }
            }
        }

        // 3) Pared de ladrillo con pilares de piedra
        for (int dx = -4; dx <= 5; dx++) {
            for (int dz = 0; dz <= 1; dz++) {
                for (int dy = 0; dy <= 5; dy++) {
                    BlockState b = ladrillo;
                    if (dx == -4 || dx == 5) {
                        b = azar.nextInt(3) == 0 ? musgo : piedra;
                    } else if (dy == 5) {
                        b = piedra;
                    }
                    poner(mundo, cx + dx, base + dy, cz + dz, b);
                }
            }
        }

        // 4) Marco del portal (arco) y portal
        for (int dz = 0; dz <= 1; dz++) {
            for (int dy = 0; dy <= 2; dy++) {
                poner(mundo, cx - 1, base + dy, cz + dz, musgo);
                poner(mundo, cx + 2, base + dy, cz + dz, musgo);
                poner(mundo, cx, base + dy, cz + dz, portal);
                poner(mundo, cx + 1, base + dy, cz + dz, portal);
            }
            for (int dx = -1; dx <= 2; dx++) {
                poner(mundo, cx + dx, base + 3, cz + dz, cincelado);
            }
        }

        // 5) Decoración: faroles, cofres y cartel
        BlockState farol = ModBlocks.FAROL_ENCANTADO.get().defaultBlockState();
        BlockState cofre = ModBlocks.COFRE_ENCANTADO.get().defaultBlockState();
        poner(mundo, cx - 2, base, cz - 1, farol);
        poner(mundo, cx + 3, base, cz - 1, farol);
        poner(mundo, cx + 4, base, cz - 1, cofre);
        poner(mundo, cx + 5, base, cz - 1, cofre);
        poner(mundo, cx + 5, base + 1, cz - 1, farol);

        BlockPos posCartel = new BlockPos(cx - 3, base + 2, cz - 1);
        BlockState cartel = Blocks.OAK_WALL_SIGN.defaultBlockState().setValue(HorizontalBlock.FACING, Direction.NORTH);
        mundo.setBlock(posCartel, cartel, 2);
        TileEntity te = mundo.getBlockEntity(posCartel);
        if (te instanceof SignTileEntity) {
            SignTileEntity letrero = (SignTileEntity) te;
            letrero.setMessage(1, new StringTextComponent("9 3/4"));
            letrero.setChanged();
            mundo.sendBlockUpdated(posCartel, cartel, cartel, 3);
        }

        return new BlockPos(cx, base, cz);
    }

    /** Posición (en bloques) donde aparece el jugador al salir del portal: delante del arco, mirando al norte. */
    public static double[] llegada(BlockPos origen) {
        return new double[]{origen.getX() + 1.0D, origen.getY(), origen.getZ() - 1.5D};
    }

    private static void poner(ServerWorld mundo, int x, int y, int z, BlockState estado) {
        mundo.setBlock(new BlockPos(x, y, z), estado, 2);
    }

    private static int alturaSuelo(ServerWorld mundo, int x, int z) {
        int y = mundo.getHeight(Heightmap.Type.WORLD_SURFACE, x, z);
        while (y > 2 && esAireOReemplazable(mundo.getBlockState(new BlockPos(x, y - 1, z)))) {
            y--;
        }
        return y;
    }

    private static boolean esAireOReemplazable(BlockState s) {
        Material m = s.getMaterial();
        return s.isAir()
                || s.is(BlockTags.LEAVES)
                || s.is(BlockTags.LOGS)
                || m.isReplaceable()
                || m == Material.PLANT
                || m == Material.REPLACEABLE_PLANT;
    }
}
