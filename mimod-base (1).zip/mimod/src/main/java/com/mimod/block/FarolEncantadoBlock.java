package com.mimod.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;

public class FarolEncantadoBlock extends Block {
    private static final VoxelShape FORMA = Block.box(4.5D, 0.0D, 4.5D, 11.5D, 12.0D, 11.5D);

    public FarolEncantadoBlock(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public VoxelShape getShape(BlockState estado, IBlockReader mundo, BlockPos pos, ISelectionContext contexto) {
        return FORMA;
    }
}
