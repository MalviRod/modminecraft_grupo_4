package com.mimod.block;

import com.mimod.util.LlaveUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

/** Puerta que solo se abre (y se cierra) con la llave encantada. */
public class PuertaEncantadaBlock extends DoorBlock {

    public PuertaEncantadaBlock(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public ActionResultType use(BlockState estado, World mundo, BlockPos pos, PlayerEntity jugador,
                                Hand mano, BlockRayTraceResult impacto) {
        if (!LlaveUtil.tieneLlave(jugador)) {
            if (!mundo.isClientSide) {
                jugador.displayClientMessage(
                        new StringTextComponent("La puerta está cerrada. Necesitas la llave encantada."), true);
            }
            return ActionResultType.sidedSuccess(mundo.isClientSide);
        }
        return super.use(estado, mundo, pos, jugador, mano, impacto);
    }

    // Sin esto, la redstone abriría la puerta sin llave.
    @Override
    public void neighborChanged(BlockState estado, World mundo, BlockPos pos, Block bloque,
                                BlockPos desde, boolean movido) {
    }
}
