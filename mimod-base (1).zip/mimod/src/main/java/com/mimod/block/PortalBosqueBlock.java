package com.mimod.block;

import com.mimod.world.PortalManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.Random;

/** Bloque del portal: al tocarlo, el jugador viaja entre el mundo normal y el Bosque Encantado. */
public class PortalBosqueBlock extends Block {

    public PortalBosqueBlock(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public void entityInside(BlockState estado, World mundo, BlockPos pos, Entity entidad) {
        if (!mundo.isClientSide && entidad instanceof ServerPlayerEntity) {
            PortalManager.usarPortal((ServerPlayerEntity) entidad);
        }
    }

    @OnlyIn(Dist.CLIENT)
    @Override
    public void animateTick(BlockState estado, World mundo, BlockPos pos, Random azar) {
        if (azar.nextInt(3) == 0) {
            mundo.addParticle(ParticleTypes.PORTAL,
                    pos.getX() + azar.nextDouble(), pos.getY() + azar.nextDouble(), pos.getZ() + azar.nextDouble(),
                    (azar.nextDouble() - 0.5D) * 0.4D, (azar.nextDouble() - 0.5D) * 0.4D, (azar.nextDouble() - 0.5D) * 0.4D);
        }
    }
}
