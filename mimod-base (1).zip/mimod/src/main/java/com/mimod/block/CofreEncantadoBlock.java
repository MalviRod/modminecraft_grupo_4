package com.mimod.block;

import com.mimod.tileentity.CofreEncantadoTileEntity;
import com.mimod.util.LlaveUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

/** Cofre que solo se abre haciendo clic derecho con la llave encantada en la mano. */
public class CofreEncantadoBlock extends Block {

    public CofreEncantadoBlock(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public boolean hasTileEntity(BlockState estado) {
        return true;
    }

    @Override
    public TileEntity createTileEntity(BlockState estado, IBlockReader mundo) {
        return new CofreEncantadoTileEntity();
    }

    @Override
    public ActionResultType use(BlockState estado, World mundo, BlockPos pos, PlayerEntity jugador,
                                Hand mano, BlockRayTraceResult impacto) {
        if (mundo.isClientSide) {
            return ActionResultType.SUCCESS;
        }
        if (!LlaveUtil.tieneLlave(jugador)) {
            jugador.displayClientMessage(
                    new StringTextComponent("El cofre está cerrado. Necesitas la llave encantada."), true);
            return ActionResultType.CONSUME;
        }
        TileEntity te = mundo.getBlockEntity(pos);
        if (te instanceof CofreEncantadoTileEntity) {
            jugador.openMenu((INamedContainerProvider) te);
        }
        return ActionResultType.CONSUME;
    }

    // Al romper el cofre, suelta lo que tenía guardado.
    @Override
    public void onRemove(BlockState estado, World mundo, BlockPos pos, BlockState nuevo, boolean movido) {
        if (!estado.is(nuevo.getBlock())) {
            TileEntity te = mundo.getBlockEntity(pos);
            if (te instanceof IInventory) {
                InventoryHelper.dropContents(mundo, pos, (IInventory) te);
            }
        }
        super.onRemove(estado, mundo, pos, nuevo, movido);
    }
}
