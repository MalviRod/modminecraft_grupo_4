package com.mimod.tileentity;

import com.mimod.init.ModTileEntities;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.inventory.container.ChestContainer;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.LockableLootTileEntity;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;

public class CofreEncantadoTileEntity extends LockableLootTileEntity {
    private NonNullList<ItemStack> objetos = NonNullList.withSize(27, ItemStack.EMPTY);

    public CofreEncantadoTileEntity() {
        super(ModTileEntities.COFRE_ENCANTADO.get());
    }

    @Override
    public int getContainerSize() {
        return 27;
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return objetos;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> nuevos) {
        this.objetos = nuevos;
    }

    @Override
    protected ITextComponent getDefaultName() {
        return new TranslationTextComponent("container.mimod.cofre_encantado");
    }

    @Override
    protected Container createMenu(int id, PlayerInventory inventario) {
        return ChestContainer.threeRows(id, inventario, this);
    }

    @Override
    public CompoundNBT save(CompoundNBT nbt) {
        super.save(nbt);
        if (!this.trySaveLootTable(nbt)) {
            ItemStackHelper.saveAllItems(nbt, this.objetos);
        }
        return nbt;
    }

    @Override
    public void load(BlockState estado, CompoundNBT nbt) {
        super.load(estado, nbt);
        this.objetos = NonNullList.withSize(27, ItemStack.EMPTY);
        if (!this.tryLoadLootTable(nbt)) {
            ItemStackHelper.loadAllItems(nbt, this.objetos);
        }
    }
}
