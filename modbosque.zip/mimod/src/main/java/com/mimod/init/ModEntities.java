package com.mimod.init;

import com.mimod.MiMod;
import com.mimod.entity.CiclopeEntity;
import com.mimod.entity.HadaEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, MiMod.MOD_ID);

    public static final RegistryObject<EntityType<CiclopeEntity>> CICLOPE = ENTITIES.register("ciclope",
            () -> EntityType.Builder.of(CiclopeEntity::new, EntityClassification.MONSTER)
                    .sized(1.8F, 3.5F)
                    .clientTrackingRange(10)
                    .build("ciclope"));

    public static final RegistryObject<EntityType<HadaEntity>> HADA = ENTITIES.register("hada",
            () -> EntityType.Builder.of(HadaEntity::new, EntityClassification.CREATURE)
                    .sized(0.6F, 1.0F)
                    .clientTrackingRange(10)
                    .build("hada"));
}
