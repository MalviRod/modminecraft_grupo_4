package com.mimod.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntitySize;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Pose;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.goal.HurtByTargetGoal;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomWalkingGoal;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.world.IServerWorld;
import net.minecraft.world.World;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.entity.SpawnReason;

import java.util.Random;

/** Cíclope: criatura gigante y territorial del bosque encantado (3,5 bloques de alto). */
public class CiclopeEntity extends MonsterEntity {

    public CiclopeEntity(EntityType<? extends CiclopeEntity> tipo, World mundo) {
        super(tipo, mundo);
        this.maxUpStep = 1.0F;
        this.xpReward = 25;
    }

    public static AttributeModifierMap.MutableAttribute crearAtributos() {
        return MonsterEntity.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 70.0D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 14.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new SwimGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomWalkingGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtGoal(this, PlayerEntity.class, 10.0F));
        this.goalSelector.addGoal(7, new LookRandomlyGoal(this));
        // Territorial: responde a quien lo golpea y ataca a los intrusos (jugadores) que se acercan.
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntitySize size) {
        return 3.1F;
    }

    @Override
    public boolean doHurtTarget(Entity objetivo) {
        boolean golpeo = super.doHurtTarget(objetivo);
        if (golpeo && objetivo instanceof LivingEntity) {
            objetivo.setDeltaMovement(objetivo.getDeltaMovement().add(0.0D, 0.45D, 0.0D));
        }
        return golpeo;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource fuente) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState estado) {
        this.playSound(SoundEvents.RAVAGER_STEP, 0.6F, 0.8F);
    }

    @Override
    protected float getSoundVolume() {
        return 1.2F;
    }

    /** Aparece sobre suelo sólido sin importar la luz (es una criatura del bosque, no de cuevas oscuras). */
    public static boolean puedeAparecer(EntityType<CiclopeEntity> tipo, IServerWorld mundo, SpawnReason razon,
                                        BlockPos pos, Random azar) {
        return mundo.getBlockState(pos.below()).getMaterial().isSolid();
    }
}
