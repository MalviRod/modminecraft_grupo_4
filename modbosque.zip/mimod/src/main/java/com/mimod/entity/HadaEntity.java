package com.mimod.entity;

import net.minecraft.block.BlockState;
import net.minecraft.entity.CreatureEntity;
import net.minecraft.entity.EntitySize;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.Pose;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.controller.FlyingMovementController;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.FlyingPathNavigator;
import net.minecraft.pathfinding.PathNavigator;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IServerWorld;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.Random;

/**
 * Hada: criatura mágica pequeña (1 bloque). Vuela, deja un rastro de partículas,
 * da efectos beneficiosos a los jugadores cercanos y los guía por el bosque.
 */
public class HadaEntity extends CreatureEntity {
    public static final int VOLANDO = 0;
    public static final int USANDO_MAGIA = 1;
    public static final int GUIANDO = 2;

    private static final DataParameter<Integer> ESTADO =
            EntityDataManager.defineId(HadaEntity.class, DataSerializers.INT);

    private int magiaTicks = 0;
    private int enfriamiento = 200;
    private boolean guiando = false;

    public HadaEntity(EntityType<? extends HadaEntity> tipo, World mundo) {
        super(tipo, mundo);
        this.moveControl = new FlyingMovementController(this, 20, true);
        this.setNoGravity(true);
    }

    public static AttributeModifierMap.MutableAttribute crearAtributos() {
        return MobEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ESTADO, VOLANDO);
    }

    public int getEstado() {
        return this.entityData.get(ESTADO);
    }

    private void setEstado(int estado) {
        this.entityData.set(ESTADO, estado);
    }

    @Override
    protected PathNavigator createNavigation(World mundo) {
        FlyingPathNavigator nav = new FlyingPathNavigator(this, mundo);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new SwimGoal(this));
        this.goalSelector.addGoal(2, new GuiarJugadorGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new LookAtGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.addGoal(5, new LookRandomlyGoal(this));
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntitySize size) {
        return size.height * 0.7F;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level.isClientSide) {
            if (this.random.nextInt(2) == 0) {
                this.level.addParticle(ParticleTypes.WITCH, this.getRandomX(0.6D), this.getY() + 0.3D + this.random.nextDouble() * 0.5D,
                        this.getRandomZ(0.6D), 0.0D, -0.01D, 0.0D);
            }
            if (this.random.nextInt(4) == 0) {
                this.level.addParticle(ParticleTypes.END_ROD, this.getRandomX(0.6D), this.getY() + 0.3D + this.random.nextDouble() * 0.5D,
                        this.getRandomZ(0.6D), 0.0D, -0.02D, 0.0D);
            }
            if (this.getEstado() == USANDO_MAGIA) {
                for (int i = 0; i < 3; i++) {
                    this.level.addParticle(ParticleTypes.END_ROD, this.getRandomX(1.2D), this.getY() + this.random.nextDouble() * 1.2D,
                            this.getRandomZ(1.2D), (this.random.nextDouble() - 0.5D) * 0.05D, 0.03D, (this.random.nextDouble() - 0.5D) * 0.05D);
                }
            }
            return;
        }

        if (this.magiaTicks > 0) {
            this.magiaTicks--;
        }
        if (this.enfriamiento > 0) {
            this.enfriamiento--;
        }
        if (this.enfriamiento <= 0 && this.tickCount % 20 == 0) {
            PlayerEntity jugador = this.level.getNearestPlayer(this, 6.0D);
            if (jugador != null && !jugador.isSpectator()) {
                darEfecto(jugador);
                this.magiaTicks = 30;
                this.enfriamiento = 600;
            }
        }
        int nuevo = this.magiaTicks > 0 ? USANDO_MAGIA : (this.guiando ? GUIANDO : VOLANDO);
        if (nuevo != getEstado()) {
            setEstado(nuevo);
        }
    }

    private void darEfecto(PlayerEntity jugador) {
        Effect[] efectos = {Effects.REGENERATION, Effects.MOVEMENT_SPEED, Effects.JUMP,
                Effects.NIGHT_VISION, Effects.DAMAGE_RESISTANCE, Effects.ABSORPTION};
        Effect efecto = efectos[this.random.nextInt(efectos.length)];
        int duracion = efecto == Effects.NIGHT_VISION ? 400 : 200;
        jugador.addEffect(new EffectInstance(efecto, duracion, 0));
        this.level.playSound(null, this.blockPosition(), SoundEvents.NOTE_BLOCK_CHIME, SoundCategory.NEUTRAL, 1.0F, 1.6F);
    }

    void setGuiando(boolean valor) {
        this.guiando = valor;
    }

    @Override
    public boolean causeFallDamage(float distancia, float multiplicador) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean enSuelo, BlockState estado, BlockPos pos) {
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.NOTE_BLOCK_CHIME;
    }

    @Override
    public float getVoicePitch() {
        return 1.5F + this.random.nextFloat() * 0.4F;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource fuente) {
        return SoundEvents.VEX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VEX_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.5F;
    }

    public static boolean puedeAparecer(EntityType<HadaEntity> tipo, IServerWorld mundo, SpawnReason razon,
                                        BlockPos pos, Random azar) {
        return true;
    }

    /** La hada se acerca al jugador y lo acompaña, flotando a su lado. */
    static class GuiarJugadorGoal extends Goal {
        private final HadaEntity hada;
        private PlayerEntity jugador;

        GuiarJugadorGoal(HadaEntity hada) {
            this.hada = hada;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            this.jugador = this.hada.level.getNearestPlayer(this.hada, 16.0D);
            return this.jugador != null && !this.jugador.isSpectator()
                    && this.hada.distanceToSqr(this.jugador) > 12.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return this.jugador != null && this.jugador.isAlive() && !this.jugador.isSpectator()
                    && this.hada.distanceToSqr(this.jugador) > 6.0D
                    && this.hada.distanceToSqr(this.jugador) < 32.0D * 32.0D;
        }

        @Override
        public void start() {
            this.hada.setGuiando(true);
        }

        @Override
        public void tick() {
            this.hada.getLookControl().setLookAt(this.jugador, 30.0F, 30.0F);
            this.hada.getNavigation().moveTo(this.jugador.getX(), this.jugador.getY() + 1.8D, this.jugador.getZ(), 1.0D);
        }

        @Override
        public void stop() {
            this.hada.getNavigation().stop();
            this.hada.setGuiando(false);
            this.jugador = null;
        }
    }
}
