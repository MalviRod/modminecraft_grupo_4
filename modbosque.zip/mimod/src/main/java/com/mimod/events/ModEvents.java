package com.mimod.events;

import com.mimod.MiMod;
import com.mimod.init.ModEntities;
import com.mimod.world.ModFeatures;
import com.mimod.world.PortalSavedData;
import com.mimod.world.PortalStructure;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.world.biome.MobSpawnInfo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MiMod.MOD_ID)
public class ModEvents {
    private static final ResourceLocation BIOMA_BOSQUE = new ResourceLocation(MiMod.MOD_ID, "bosque_encantado");

    /** Añade árboles y mineral al bioma del bosque, y el mineral también al mundo normal. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void alCargarBioma(BiomeLoadingEvent evento) {
        // Criaturas del bosque encantado (se agregan antes del chequeo de features)
        if (BIOMA_BOSQUE.equals(evento.getName())) {
            evento.getSpawns().addSpawn(EntityClassification.MONSTER,
                    new MobSpawnInfo.Spawners(ModEntities.CICLOPE.get(), 8, 1, 1));
            evento.getSpawns().addSpawn(EntityClassification.CREATURE,
                    new MobSpawnInfo.Spawners(ModEntities.HADA.get(), 14, 1, 3));
        }
        if (ModFeatures.ARBOL_CONFIGURADO == null || ModFeatures.MINERAL_CONFIGURADO == null) {
            return;
        }
        if (BIOMA_BOSQUE.equals(evento.getName())) {
            evento.getGeneration().addFeature(GenerationStage.Decoration.VEGETAL_DECORATION, ModFeatures.ARBOL_CONFIGURADO);
            evento.getGeneration().addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, ModFeatures.MINERAL_CONFIGURADO);
        } else if (evento.getCategory() != Biome.Category.NETHER && evento.getCategory() != Biome.Category.THEEND) {
            evento.getGeneration().addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, ModFeatures.MINERAL_CONFIGURADO);
        }
    }

    /** La primera vez que alguien entra al mundo, se construye el portal unos pasos al sur de donde aparece. */
    @SubscribeEvent
    public static void alEntrar(PlayerEvent.PlayerLoggedInEvent evento) {
        if (!(evento.getPlayer() instanceof ServerPlayerEntity)) {
            return;
        }
        ServerPlayerEntity jugador = (ServerPlayerEntity) evento.getPlayer();
        if (!jugador.level.dimension().equals(World.OVERWORLD)) {
            return;
        }
        MinecraftServer servidor = jugador.getServer();
        if (servidor == null) {
            return;
        }
        ServerWorld overworld = servidor.overworld();
        PortalSavedData datos = PortalSavedData.get(overworld);
        if (datos.getOrigenOverworld() != null) {
            return;
        }
        BlockPos pos = jugador.blockPosition();
        BlockPos origen = PortalStructure.construir(overworld, pos.getX() - 1, pos.getZ() + 9);
        datos.setOrigenOverworld(origen);
    }
}
