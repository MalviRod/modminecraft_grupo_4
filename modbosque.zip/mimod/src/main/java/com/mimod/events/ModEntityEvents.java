package com.mimod.events;

import com.mimod.MiMod;
import com.mimod.entity.CiclopeEntity;
import com.mimod.entity.HadaEntity;
import com.mimod.init.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MiMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntityEvents {
    @SubscribeEvent
    public static void registrarAtributos(EntityAttributeCreationEvent evento) {
        evento.put(ModEntities.CICLOPE.get(), CiclopeEntity.crearAtributos().build());
        evento.put(ModEntities.HADA.get(), HadaEntity.crearAtributos().build());
    }
}
