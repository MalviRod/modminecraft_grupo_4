package com.mimod.item;

import net.minecraft.entity.EntityType;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.nbt.CompoundNBT;

import javax.annotation.Nullable;
import java.util.function.Supplier;

/**
 * Huevo de aparición que acepta un EntityType registrado más tarde (DeferredRegister),
 * porque los ítems se registran antes que las entidades.
 */
public class ModSpawnEggItem extends SpawnEggItem {
    private final Supplier<? extends EntityType<?>> tipo;

    public ModSpawnEggItem(Supplier<? extends EntityType<?>> tipo, int colorFondo, int colorPuntos, Properties propiedades) {
        super(null, colorFondo, colorPuntos, propiedades);
        this.tipo = tipo;
    }

    @Override
    public EntityType<?> getType(@Nullable CompoundNBT nbt) {
        if (nbt != null && nbt.contains("EntityTag", 10)) {
            CompoundNBT etiqueta = nbt.getCompound("EntityTag");
            if (etiqueta.contains("id", 8)) {
                return EntityType.byString(etiqueta.getString("id")).orElse(this.tipo.get());
            }
        }
        return this.tipo.get();
    }
}
