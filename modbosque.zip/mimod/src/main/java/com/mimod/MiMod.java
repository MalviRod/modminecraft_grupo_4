package com.mimod;

import com.mimod.entity.CiclopeEntity;
import com.mimod.entity.HadaEntity;
import com.mimod.init.ModBlocks;
import com.mimod.init.ModEntities;
import com.mimod.init.ModItems;
import com.mimod.init.ModTileEntities;
import com.mimod.world.ModFeatures;
import net.minecraft.entity.EntitySpawnPlacementRegistry;
import net.minecraft.world.gen.Heightmap;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(MiMod.MOD_ID)
public class MiMod {
    public static final String MOD_ID = "mimod";
    public static final Logger LOGGER = LogManager.getLogger();

    public MiMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTileEntities.TILE_ENTITIES.register(bus);
        ModFeatures.FEATURES.register(bus);
        ModEntities.ENTITIES.register(bus);

        bus.addListener(this::setup);
    }

    private void setup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModFeatures::registrarConfigurados);
        event.enqueueWork(() -> {
            EntitySpawnPlacementRegistry.register(ModEntities.CICLOPE.get(),
                    EntitySpawnPlacementRegistry.PlacementType.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                    CiclopeEntity::puedeAparecer);
            EntitySpawnPlacementRegistry.register(ModEntities.HADA.get(),
                    EntitySpawnPlacementRegistry.PlacementType.NO_RESTRICTIONS, Heightmap.Type.MOTION_BLOCKING,
                    HadaEntity::puedeAparecer);
        });
        LOGGER.info("Bosque Encantado cargado correctamente en 1.16.5");
    }
}
