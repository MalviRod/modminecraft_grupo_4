package com.mimod.client.render;

import com.mimod.MiMod;
import com.mimod.client.model.CiclopeModel;
import com.mimod.entity.CiclopeEntity;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.util.ResourceLocation;

public class CiclopeRenderer extends MobRenderer<CiclopeEntity, CiclopeModel> {
    private static final ResourceLocation NEUTRAL = new ResourceLocation(MiMod.MOD_ID, "textures/entity/ciclope_neutral.png");
    private static final ResourceLocation ENOJADO = new ResourceLocation(MiMod.MOD_ID, "textures/entity/ciclope_enojado.png");
    private static final ResourceLocation ATACANDO = new ResourceLocation(MiMod.MOD_ID, "textures/entity/ciclope_atacando.png");

    public CiclopeRenderer(EntityRendererManager manager) {
        super(manager, new CiclopeModel(), 1.2F);
    }

    @Override
    public ResourceLocation getTextureLocation(CiclopeEntity entidad) {
        if (entidad.swinging) {
            return ATACANDO;
        }
        return entidad.isAggressive() ? ENOJADO : NEUTRAL;
    }
}
