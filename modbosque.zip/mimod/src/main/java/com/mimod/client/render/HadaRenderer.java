package com.mimod.client.render;

import com.mimod.MiMod;
import com.mimod.client.model.HadaModel;
import com.mimod.entity.HadaEntity;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

public class HadaRenderer extends MobRenderer<HadaEntity, HadaModel> {
    private static final ResourceLocation NEUTRAL = new ResourceLocation(MiMod.MOD_ID, "textures/entity/hada_neutral.png");
    private static final ResourceLocation FELIZ = new ResourceLocation(MiMod.MOD_ID, "textures/entity/hada_feliz.png");
    private static final ResourceLocation SORPRENDIDA = new ResourceLocation(MiMod.MOD_ID, "textures/entity/hada_sorprendida.png");

    public HadaRenderer(EntityRendererManager manager) {
        super(manager, new HadaModel(), 0.25F);
    }

    @Override
    public ResourceLocation getTextureLocation(HadaEntity hada) {
        if (hada.hurtTime > 0) {
            return SORPRENDIDA;
        }
        return hada.getEstado() != HadaEntity.VOLANDO ? FELIZ : NEUTRAL;
    }

    /** Brilla en la oscuridad, como en la ficha de concepto. */
    @Override
    protected int getBlockLightLevel(HadaEntity hada, BlockPos pos) {
        return 15;
    }
}
