package com.mimod.client.model;

import com.mimod.entity.HadaEntity;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.util.math.MathHelper;

public class HadaModel extends EntityModel<HadaEntity> {
    private final ModelRenderer cabeza;
    private final ModelRenderer cuerpo;
    private final ModelRenderer falda;
    private final ModelRenderer brazoDer;
    private final ModelRenderer brazoIzq;
    private final ModelRenderer piernaDer;
    private final ModelRenderer piernaIzq;
    private final ModelRenderer alaIzqGrande;
    private final ModelRenderer alaDerGrande;
    private final ModelRenderer alaIzqChica;
    private final ModelRenderer alaDerChica;

    public HadaModel() {
        this.texWidth = 64;
        this.texHeight = 64;

        this.cabeza = new ModelRenderer(this, 0, 0);
        this.cabeza.setPos(0.0F, 15.0F, 0.0F);
        this.cabeza.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F);

        ModelRenderer pelo = new ModelRenderer(this, 32, 0);
        pelo.setPos(0.0F, 0.0F, 0.0F);
        pelo.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, 0.4F);
        this.cabeza.addChild(pelo);

        ModelRenderer peloTrasero = new ModelRenderer(this, 40, 16);
        peloTrasero.setPos(0.0F, 0.0F, 0.0F);
        peloTrasero.addBox(-4.0F, -4.0F, 4.4F, 8.0F, 12.0F, 1.0F);
        this.cabeza.addChild(peloTrasero);

        // corona de flores
        ModelRenderer flor1 = new ModelRenderer(this, 40, 30);
        flor1.addBox(-5.4F, -8.6F, -2.0F, 2.0F, 2.0F, 2.0F);
        this.cabeza.addChild(flor1);
        ModelRenderer flor2 = new ModelRenderer(this, 48, 30);
        flor2.addBox(3.4F, -8.6F, -2.0F, 2.0F, 2.0F, 2.0F);
        this.cabeza.addChild(flor2);
        ModelRenderer flor3 = new ModelRenderer(this, 56, 30);
        flor3.addBox(-1.0F, -9.2F, -4.6F, 2.0F, 2.0F, 2.0F);
        this.cabeza.addChild(flor3);

        this.cuerpo = new ModelRenderer(this, 0, 16);
        this.cuerpo.setPos(0.0F, 15.0F, 0.0F);
        this.cuerpo.addBox(-2.5F, 0.0F, -1.5F, 5.0F, 5.0F, 3.0F);

        this.falda = new ModelRenderer(this, 16, 16);
        this.falda.setPos(0.0F, 19.0F, 0.0F);
        this.falda.addBox(-3.5F, 0.0F, -2.5F, 7.0F, 4.0F, 5.0F);

        this.piernaDer = new ModelRenderer(this, 0, 26);
        this.piernaDer.setPos(-1.2F, 20.0F, 0.0F);
        this.piernaDer.addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F);
        this.piernaIzq = new ModelRenderer(this, 8, 26);
        this.piernaIzq.setPos(1.2F, 20.0F, 0.0F);
        this.piernaIzq.addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F);

        this.brazoDer = new ModelRenderer(this, 16, 26);
        this.brazoDer.setPos(-3.5F, 15.5F, 0.0F);
        this.brazoDer.addBox(-1.0F, -0.5F, -1.0F, 2.0F, 5.0F, 2.0F);
        this.brazoIzq = new ModelRenderer(this, 24, 26);
        this.brazoIzq.setPos(3.5F, 15.5F, 0.0F);
        this.brazoIzq.addBox(-1.0F, -0.5F, -1.0F, 2.0F, 5.0F, 2.0F);

        // alas (se articulan en la espalda)
        this.alaIzqGrande = new ModelRenderer(this, 0, 34);
        this.alaIzqGrande.setPos(0.8F, 15.0F, 1.7F);
        this.alaIzqGrande.addBox(0.0F, -9.0F, 0.0F, 10.0F, 12.0F, 1.0F);
        this.alaDerGrande = new ModelRenderer(this, 0, 34);
        this.alaDerGrande.mirror = true;
        this.alaDerGrande.setPos(-0.8F, 15.0F, 1.7F);
        this.alaDerGrande.addBox(-10.0F, -9.0F, 0.0F, 10.0F, 12.0F, 1.0F);
        this.alaIzqChica = new ModelRenderer(this, 24, 34);
        this.alaIzqChica.setPos(0.8F, 18.0F, 1.7F);
        this.alaIzqChica.addBox(0.0F, -1.0F, 0.0F, 7.0F, 8.0F, 1.0F);
        this.alaDerChica = new ModelRenderer(this, 24, 34);
        this.alaDerChica.mirror = true;
        this.alaDerChica.setPos(-0.8F, 18.0F, 1.7F);
        this.alaDerChica.addBox(-7.0F, -1.0F, 0.0F, 7.0F, 8.0F, 1.0F);
    }

    @Override
    public void setupAnim(HadaEntity hada, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.cabeza.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.cabeza.xRot = headPitch * ((float) Math.PI / 180F);

        // aleteo
        float aleteo = MathHelper.sin(ageInTicks * 1.1F) * 0.45F;
        float base = 0.35F + aleteo;
        this.alaIzqGrande.yRot = -base;
        this.alaDerGrande.yRot = base;
        this.alaIzqChica.yRot = -(base * 0.8F);
        this.alaDerChica.yRot = base * 0.8F;
        this.alaIzqGrande.zRot = -0.1F;
        this.alaDerGrande.zRot = 0.1F;
        this.alaIzqChica.zRot = -0.5F;
        this.alaDerChica.zRot = 0.5F;

        // piernas colgando con balanceo suave
        float vaiven = MathHelper.cos(ageInTicks * 0.15F) * 0.1F;
        this.piernaDer.xRot = 0.25F + vaiven;
        this.piernaIzq.xRot = 0.25F - vaiven;
        this.brazoDer.xRot = 0.0F;
        this.brazoIzq.xRot = 0.0F;
        this.brazoDer.zRot = 0.15F + vaiven * 0.5F;
        this.brazoIzq.zRot = -0.15F - vaiven * 0.5F;
        this.cuerpo.xRot = 0.15F;
        this.falda.xRot = 0.15F;

        int estado = hada.getEstado();
        if (estado == HadaEntity.USANDO_MAGIA) {
            this.brazoDer.xRot = -2.6F + MathHelper.sin(ageInTicks * 0.5F) * 0.15F;
            this.brazoIzq.xRot = -2.6F + MathHelper.sin(ageInTicks * 0.5F + 1.0F) * 0.15F;
            this.brazoDer.zRot = 0.3F;
            this.brazoIzq.zRot = -0.3F;
        } else if (estado == HadaEntity.GUIANDO) {
            this.brazoDer.xRot = -1.5F;
            this.brazoDer.zRot = 0.05F;
            this.brazoIzq.xRot = 0.5F;
            this.cuerpo.xRot = 0.35F;
            this.falda.xRot = 0.35F;
        }
    }

    @Override
    public void renderToBuffer(MatrixStack pila, IVertexBuilder buffer, int luz, int overlay,
                               float r, float g, float b, float a) {
        this.cabeza.render(pila, buffer, luz, overlay, r, g, b, a);
        this.cuerpo.render(pila, buffer, luz, overlay, r, g, b, a);
        this.falda.render(pila, buffer, luz, overlay, r, g, b, a);
        this.piernaDer.render(pila, buffer, luz, overlay, r, g, b, a);
        this.piernaIzq.render(pila, buffer, luz, overlay, r, g, b, a);
        this.brazoDer.render(pila, buffer, luz, overlay, r, g, b, a);
        this.brazoIzq.render(pila, buffer, luz, overlay, r, g, b, a);
        this.alaIzqGrande.render(pila, buffer, luz, overlay, r, g, b, a);
        this.alaDerGrande.render(pila, buffer, luz, overlay, r, g, b, a);
        this.alaIzqChica.render(pila, buffer, luz, overlay, r, g, b, a);
        this.alaDerChica.render(pila, buffer, luz, overlay, r, g, b, a);
    }
}
