package com.mimod.client.model;

import com.mimod.entity.CiclopeEntity;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.util.math.MathHelper;

public class CiclopeModel extends EntityModel<CiclopeEntity> {
    private final ModelRenderer cabeza;
    private final ModelRenderer cuerpo;
    private final ModelRenderer taparrabos;
    private final ModelRenderer brazoDer;
    private final ModelRenderer brazoIzq;
    private final ModelRenderer piernaDer;
    private final ModelRenderer piernaIzq;
    private final ModelRenderer garrote;

    public CiclopeModel() {
        this.texWidth = 128;
        this.texHeight = 160;

        this.piernaDer = new ModelRenderer(this, 40, 70);
        this.piernaDer.setPos(-5.5F, 4.0F, 0.0F);
        this.piernaDer.addBox(-4.5F, 0.0F, -4.5F, 9.0F, 20.0F, 9.0F);

        this.piernaIzq = new ModelRenderer(this, 40, 70);
        this.piernaIzq.mirror = true;
        this.piernaIzq.setPos(5.5F, 4.0F, 0.0F);
        this.piernaIzq.addBox(-4.5F, 0.0F, -4.5F, 9.0F, 20.0F, 9.0F);

        this.cuerpo = new ModelRenderer(this, 0, 32);
        this.cuerpo.setPos(0.0F, 4.0F, 0.0F);
        this.cuerpo.addBox(-11.0F, -22.0F, -6.0F, 22.0F, 22.0F, 12.0F);

        this.taparrabos = new ModelRenderer(this, 0, 112);
        this.taparrabos.setPos(0.0F, -5.0F, 0.0F);
        this.taparrabos.addBox(-12.0F, 0.0F, -7.0F, 24.0F, 9.0F, 14.0F);

        this.cabeza = new ModelRenderer(this, 0, 0);
        this.cabeza.setPos(0.0F, -17.0F, -1.0F);
        this.cabeza.addBox(-7.0F, -14.0F, -7.0F, 14.0F, 14.0F, 14.0F);

        this.brazoDer = new ModelRenderer(this, 0, 70);
        this.brazoDer.setPos(-15.0F, -15.0F, 0.0F);
        this.brazoDer.addBox(-4.5F, -3.0F, -4.5F, 9.0F, 26.0F, 9.0F);

        this.brazoIzq = new ModelRenderer(this, 0, 70);
        this.brazoIzq.mirror = true;
        this.brazoIzq.setPos(15.0F, -15.0F, 0.0F);
        this.brazoIzq.addBox(-4.5F, -3.0F, -4.5F, 9.0F, 26.0F, 9.0F);

        // Garrote con pinchos, sujeto por la mano derecha
        this.garrote = new ModelRenderer(this, 80, 70);
        this.garrote.setPos(0.0F, 21.0F, -1.0F);
        this.garrote.xRot = 0.8F;
        this.garrote.addBox(-1.5F, -8.0F, -1.5F, 3.0F, 14.0F, 3.0F);
        ModelRenderer cabezaGarrote = new ModelRenderer(this, 96, 70);
        cabezaGarrote.setPos(0.0F, 0.0F, 0.0F);
        cabezaGarrote.addBox(-4.0F, -22.0F, -4.0F, 8.0F, 14.0F, 8.0F);
        this.garrote.addChild(cabezaGarrote);
        this.brazoDer.addChild(this.garrote);
    }

    @Override
    public void setupAnim(CiclopeEntity entidad, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.cabeza.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.cabeza.xRot = headPitch * ((float) Math.PI / 180F);

        float paso = limbSwing * 0.6662F;
        this.piernaDer.xRot = MathHelper.cos(paso) * 1.2F * limbSwingAmount;
        this.piernaIzq.xRot = MathHelper.cos(paso + (float) Math.PI) * 1.2F * limbSwingAmount;
        this.brazoIzq.xRot = MathHelper.cos(paso) * 0.8F * limbSwingAmount;
        this.brazoDer.xRot = MathHelper.cos(paso + (float) Math.PI) * 0.8F * limbSwingAmount;

        // respiración
        float resp = MathHelper.cos(ageInTicks * 0.09F) * 0.03F;
        this.brazoDer.zRot = 0.06F + resp;
        this.brazoIzq.zRot = -0.06F - resp;

        if (entidad.isAggressive()) {
            this.brazoDer.xRot -= 0.9F;
        }
        if (this.attackTime > 0.0F) {
            // golpe de garrote: sube por encima de la cabeza y baja
            this.brazoDer.xRot = -2.8F * MathHelper.sin(this.attackTime * (float) Math.PI);
            this.brazoIzq.xRot = -0.6F * MathHelper.sin(this.attackTime * (float) Math.PI);
        }
    }

    @Override
    public void renderToBuffer(MatrixStack pila, IVertexBuilder buffer, int luz, int overlay,
                               float r, float g, float b, float a) {
        this.piernaDer.render(pila, buffer, luz, overlay, r, g, b, a);
        this.piernaIzq.render(pila, buffer, luz, overlay, r, g, b, a);
        this.cuerpo.render(pila, buffer, luz, overlay, r, g, b, a);
        this.taparrabos.render(pila, buffer, luz, overlay, r, g, b, a);
        this.cabeza.render(pila, buffer, luz, overlay, r, g, b, a);
        this.brazoDer.render(pila, buffer, luz, overlay, r, g, b, a);
        this.brazoIzq.render(pila, buffer, luz, overlay, r, g, b, a);
    }
}
